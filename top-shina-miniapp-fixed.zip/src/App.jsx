import { useEffect } from "react";

export default function App() {
  useEffect(() => {
    if (window.Telegram.WebApp) {
      window.Telegram.WebApp.ready();
      window.Telegram.WebApp.expand();
    }
  }, []);

  const sendOrder = () => {
    const searchValue = document.getElementById("search").value;
    window.Telegram.WebApp.sendData(
      JSON.stringify({ type: "order", search: searchValue })
    );
  };

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#000', color: '#FFD700', padding: '16px' }}>
      <h1 style={{ fontSize: '28px', fontWeight: 'bold', marginBottom: '16px' }}>Top Shina</h1>
      <input
        id="search"
        type="text"
        placeholder="205/55 R16 или Michelin"
        style={{ width: '100%', padding: '8px', marginBottom: '16px', color: '#000' }}
      />
      <button
        onClick={sendOrder}
        style={{ backgroundColor: '#FFD700', color: '#000', padding: '12px', width: '100%', border: 'none', cursor: 'pointer' }}
      >
        Оформить заказ
      </button>
    </div>
  );
}